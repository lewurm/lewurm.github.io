

import System.IO
import System.Random

import Data.List
import Data.Char
import Data.Maybe

import Network

import Text.Regex

import Debug.Trace
import Control.Monad
import Control.Exception
import Control.Concurrent
import Control.Concurrent.STM

main :: IO ()

main = initApp $ mightyServer

initApp = withSocketsDo

simple = 
    do
    sock <- listenOn (PortNumber 8888)
    putStrLn "accepting a connection"
    conn <- accept sock
    greetClient conn
    putStrLn "shutdown"
    sClose sock

greetClient (h,host,port) =
    do
    putStrLn "client connected"
    hPutStrLn h "hallo"
    hClose h

tcpServer clientHandler = 
    do 
    sock <- listenOn (PortNumber 8888)
    putStrLn "accepting many connections"
    forever (acceptConnection clientHandler sock)

acceptConnection clientHandler socket = 
    do 
    conn <- accept socket
    forkIO (clientHandler conn)

advanced = tcpServer greetClient

listenAndGreetClient (h,host,port) = 
    do
    putStrLn "client connected"
    hSetBuffering h LineBuffering
    hPutStrLn h "wie heißt du?"
    input <- hGetLine h
    hPutStrLn h ("hallo " ++ input ++ "!")
    hClose h
    putStrLn "client disconnected"


server_port  = 8888
server_name  = "server"
bot_name     = "Mr. Roboto"
action_file  = "actions.txt"
request_file = "requests.txt"
welcome_file = "welcome.txt"
replace_str  = "%USER%"

mightyServer =
    do
    sock <- listenOn (PortNumber server_port)
    putStrLn "Starting Reply Thread"
    
    request_strings <- liftM lines $ readFile request_file
    action_strings  <- liftM lines $ readFile action_file
    welcome_string  <- readFile welcome_file

    (handlers,
     messages,
     users,
     botActions,
     botRequests) <- atomically (do hndlrs <- newTVar []
                                    mssgs  <- newTVar []
                                    usrs   <- newTVar []
                                    botA   <- newTVar 0
                                    botR   <- newTVar []
                                    return (hndlrs,
                                            mssgs,
                                            usrs,
                                            botA,
                                            botR)
                                    )

    forkIO (replyHandler handlers messages)
    forkIO (bot bot_name messages users request_strings botRequests action_strings botActions)
    forkIO (botBotherer botActions)

    putStrLn "Accepting many connections"
    forever (mightyAccept sock handlers messages users welcome_string botRequests)

mightyAccept socket handlers messages users welcome_string botRequests = 
    do
    conn <- accept socket
    forkIO (mightyClient conn handlers messages users welcome_string botRequests)

mightyClient (h,host,port) handlers messages users welcome_string botRequests =
    do
    putStrLn ("client connected: " ++ host ++ ":" ++ (show port))
    hSetBuffering h LineBuffering
    
    hPutStrLn h "name:"
    loginname <- readString h

    valid <- if loginname == bot_name
                then return False
                else (atomically 
                        (do us <- readTVar users
                            if not (loginname `elem` us)
                                then (do writeTVar users (loginname:us)
                                         
                                         hs <- readTVar handlers
                                         writeTVar handlers (h:hs)

                                         return True)
                                else (do return False) ))

    unless valid (do hPutStrLn h "Another user with this name is already logged in. Sry...")
    when valid (do
        hPutStrLn h (prepareForOutput welcome_string)

        serverMessage messages (loginname ++ " just logged in...")

        mightyParse h loginname messages botRequests

        hPutStrLn h "kthxby..."

        atomically (do hs <- readTVar handlers
                       writeTVar handlers (hs \\ [h])

                       us <- readTVar users
                       writeTVar users (us \\ [loginname])
                   )
        
        serverMessage messages (loginname ++ " just logged out...")
        )
    
    hClose h
    putStrLn ("client disconnected: " ++ host ++ ":" ++ (show port))

mightyParse handle loginname messages requests =
    do
    line <- readString handle
    if line == "QUIT" 
        then (do return ())
        else (do userMessage messages loginname line
                 when (line `mentions` bot_name) (do enqueueRequest requests loginname)
                 mightyParse handle loginname messages requests
                 )

readString handle = 
    do
    t <- hGetLine handle
    return (filter ( \c -> not( c `elem` "\r" ) ) t) 

enqueueValue tvarlist item =
    do
    atomically ( do list <- readTVar tvarlist
                    writeTVar tvarlist (list ++ [item]) )

enqueueMessage messages msg = enqueueValue messages msg 

userMessage messages name msg = 
    enqueueMessage messages (name ++ ": " ++ msg)

enqueueRequest requests user = enqueueValue requests user

serverMessage messages msg = 
    userMessage messages server_name msg

replyHandler handlers messages = 
    do
    putStrLn "replyhandler started"
    forever (mightyDispatch handlers messages)

mightyDispatch handlers messages = 
    do
    m <- atomically ( do ms <- readTVar messages
                         if ms == [] then retry
                                     else do writeTVar messages []
                                             return ms )
    h <- atomically ( do hs <- readTVar handlers
                         return hs )
    sequence_ [ hPutStrLn th tm | th <- h, tm' <- m, let tm = prepareForOutput tm' ]

prepareForOutput string = subRegex (mkRegex "\\\\\\\\") string "\n> "

getRandom min max = getStdRandom (randomR (min,max))

waitRandom min max = do time <- getRandom min max
                        threadDelay (time * 1000000)

mentions haystack needle = needle' `isInfixOf` haystack'
                           where needle'   = clean needle
                                 haystack' = clean haystack
                                 clean     = (map toLower) . (filter isAlphaNum)

botBotherer actions = putStrLn "Bothering bot..." >> forever botherBot
                      where botherBot = do waitRandom 5 10
                                           atomically (do a <- readTVar actions
                                                          writeTVar actions (a+1)
                                                          )

getRandomOf []   = do return Nothing
getRandomOf list = do i <- getRandom 0 ( (length list) - 1 )
                      return (Just (list!!i))

bot name messages users request_strings requests action_strings actions = 
    do 
    putStrLn (name ++ " activated...") 
    forever workHard
    where workHard        = (do cmd <- atomically (workRequest `orElse` workAction) 
                                cmd
                                )
          workRequest     = (do r <- readTVar requests
                                when (r == []) retry

                                writeTVar requests []
                                return (sequence_ [ botRequest user | user <- r ])
                                )
          workAction      = (do a <- readTVar actions
                                when (a == 0) retry
 
                                writeTVar actions 0
                                return (do replicateM_ a botAction)
                                )
          botRequest user = do r' <- getRandomOf request_strings
                               let r = fromMaybe "??" r'
                               userMessage messages name (replaceUserInString r user)
          botAction       = do a' <- getRandomOf action_strings
                               let a = fromMaybe "??" a'
                               if replace_str `isInfixOf` a 
                                  then (do users <- atomically (do us <- readTVar users
                                                                   return us)
                                           user' <- getRandomOf users
                                           let user = fromMaybe "??" user'
                                           userMessage messages name (replaceUserInString a user)
                                           )
                                  else (do userMessage messages name a)

replaceUserInString string user  = subRegex (mkRegex replace_str) string user
